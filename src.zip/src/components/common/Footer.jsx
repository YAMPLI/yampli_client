import React from 'react';
import styled, { css } from 'styled-components';
import Text from './Text';
function Footer() {
  if (window.location.pathname === '/kakao/oauth') return null;
  return (
    <FooterContainer>
      <FooterTitle>(주) YAMPLI </FooterTitle>
      <FooterContent as="ul">
        <li>
          <h6>대표</h6>&nbsp;&nbsp;설한정
          <h6>주소지</h6>&nbsp;&nbsp;인천시 계양구 작전동
        </li>
        <li>
          <h6>사업자 등록번호</h6>&nbsp;&nbsp;111-111-1111
          <h6>연락처</h6>&nbsp;&nbsp;010-111-1111
          <h6>이메일</h6>&nbsp;&nbsp;hanjeong94@naver.com
        </li>
      </FooterContent>
    </FooterContainer>
  );
}
const FooterContainer = styled.div`
  ${({ theme }) => css`
     {
      height: 250px;
      z-index: 999;
      background: ${theme.color.darkGray};
      color: ${theme.color.offWhite};
      ${theme.FlexItemCenterColumn};
      position: relative;
      text-align: center;
    }
  `}
`;

const FooterTitle = styled.h6`
  ${({ theme }) => css`
     {
      color: ${theme.color.offWhite};
      ${theme.Font('', '20px')};
      font-weight: 500;
      margin-bottom: 25px;
    }
  `}
`;
const FooterItem = styled.div`
`
const FooterContent = styled.div`
  li {
    ${({ theme: { Font } }) => css`
      ${Font('medium')}
    `}
    list-style-type: none;
    color: rgb(183, 172, 172);
    margin-bottom: 10px;
  }
  h6 {
    ${({ theme: { Font } }) => css`
      ${Font('small')}
    `}
    display: inline;
    margin-left: 15px;
    color: gray;
  }
`;

export default Footer;
