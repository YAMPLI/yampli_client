import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import PropTypes from 'prop-types';

function Main({ children }) {
  const navigate = useNavigate();
  const preventAccess = ['/home', '/group'];
  useEffect(() => {
    if (preventAccess.includes(location.pathname)) {
      localStorage.getItem('token') === null && navigate('/');
    }
  }, []);
  return <MainContainer>{children}</MainContainer>;
}

Main.propTypes = {
  children: PropTypes.element.isRequired,
};

export default Main;

// 반응형 폰트 사이즈 설정
const MainContainer = styled.div`
  height: 100vh;
  background-color: ${({ theme }) => theme.color.dark};
  padding: 20px;

  // Mobile styles
  @media ${({ theme }) => theme.media.mobile} {
    font-size: 14px;
  }

  // Tablet styles
  @media ${({ theme }) => theme.media.tablet} {
    font-size: 16px;
  }

  // Desktop styles
  @media ${({ theme }) => theme.media.desktop} {
    font-size: 18px;
  }

  // Large Desktop styles
  @media ${({ theme }) => theme.media.largeDesktop} {
    font-size: 20px;
  }
`;
