import styled from 'styled-components';

const PlayerBack = () => {};

export default PlayerBack;
