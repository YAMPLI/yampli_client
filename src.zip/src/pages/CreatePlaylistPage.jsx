import React from 'react';
import Main from '../components/common/Main';

function CreatePlaylistPage() {
  return (
    <Main>
      <h2>CreatePlaylistPage</h2>
    </Main>
  );
}

export default CreatePlaylistPage;
