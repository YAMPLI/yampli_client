import Main from '../components/common/Main';

function Home() {
  return (
    <Main>
      <div></div>
    </Main>
  );
}

export default Home;
